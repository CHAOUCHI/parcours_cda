let name=document.querySelector(".name");
name.innerText="1 er changement de texte"

function myFonction() {
    let button=document.getElementsByClassName(".button");
    button.innerText="le bouton change le paragraphe"
}