export function Task({task}){
    return (
        <div>
            <li>{task}</li>
        </div>
    )
}